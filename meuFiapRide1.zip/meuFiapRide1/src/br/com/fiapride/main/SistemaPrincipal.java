package br.com.fiapride.main;

import br.com.fiapride.model.JaquetaZiper; // import do arquivo do meu objeto

public class SistemaPrincipal {

    public static void main(String[] args) {

        // criação oficial do objeto
        JaquetaZiper jaqueta1 = new JaquetaZiper("preta", "M", "algodão");

        // chamada das funções 
        jaqueta1.exibirDetalhes();
        jaqueta1.fecharZiper();
        jaqueta1.abrirZiper();
    }
}