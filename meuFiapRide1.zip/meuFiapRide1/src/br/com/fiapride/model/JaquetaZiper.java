package br.com.fiapride.model;

public class JaquetaZiper {

    // atributos/caracteristicas
    private String cor;
    private String tamanho;
    private String material;
    private String estadoZiper; // é um dado booleano mas fiz em string por nao saber fazer booleano

    public JaquetaZiper(String cor, String tamanho, String material) {
        this.cor = cor; 
        this.tamanho = tamanho;
        this.material = material;
        this.estadoZiper = "aberto"; // uma jaqueta começa aberta
    }
    // parte dos metodos e comportamentos
    public void fecharZiper() {
        if (estadoZiper.equals("Aberto")) {
            estadoZiper = "Fechado";
            System.out.println("Zíper fechado.");
        } else {
            System.out.println("O zíper já está fechado.");
        }
    }
    public void abrirZiper() {
        if (estadoZiper.equals("Fechado")) {
            estadoZiper = "Aberto";
            System.out.println("Zíper aberto.");
        } else {
            System.out.println("O zíper já está aberto.");
        }
    }
    public void vestir() {
        System.out.println("você vestiu a jaqueta.");
    }
    public void remover() {
        System.out.println("você tirou a jaqueta.");
    }
    public void exibirDetalhes() {
        System.out.println("cor: " + cor);
        System.out.println("tamanho: " + tamanho);
        System.out.println("material: " + material);
        System.out.println("situaçao do ziper: " + estadoZiper);
    }
    // retornando tudo (dando "get" dos "this")
    public String getCor() {
        return cor;
    }
    public String getTamanho() {
        return tamanho;
    }
    public String getMaterial() {
        return material;
    }
    public String getEstadoZiper() {
        return estadoZiper;
    }
}

